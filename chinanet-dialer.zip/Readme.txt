﻿
ChinaNet Dialer PHP Version for Linux / Windows
--------------------

System Requirment: Linux or Windows With PHP

--------------------

Usage: php chinanet.php [-u username] [-p password] [-d]

Option:
    -u      Your ChinaNet Username
    -r      Your ChinaNet RSA Key
    -d      Disconnect from ChinaNet
    -v      Show version information
    -h      Show this information

Example:
         Dial:   php chinanet.php -u 18912345678 -r 2d8e...039d
    Disconnet:   php chinanet.php -d

RSA Key Generate:
    Use Firefox or IE or Chrome to open pw2rsa.htm
	
--------------------

Program Designed by Pekaikon Norckon - www.fcsys.us
2014年8月14日 TUE / 20:51 / version 0.1 