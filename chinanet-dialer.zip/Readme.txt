﻿
ChinaNet Dialer PHP Version for Linux / Windows
--------------------

System Requirment: Linux or Windows With PHP

--------------------

Usage: php E:\My Documents\GitHub\chinanet-dialer\chinanet.php [-u username] [-r rsakey] [-d] [-v] [-h]

Option:
    -u      Your ChinaNet Username
    -r      Your ChinaNet RSA Key
    -d      Disconnect from ChinaNet
    -v      Show version information
    -h      Show this information

Example:
         Dial:   php E:\My Documents\GitHub\chinanet-dialer\chinanet.php -u 1891
2345678 -r 2d8e...039d
    Disconnet:   php E:\My Documents\GitHub\chinanet-dialer\chinanet.php -d

RSA Key Generate:
    Use Firefox or Chrome to open pw2rsa.htm

--------------------

Program Designed by Pekaikon Norckon - www.fcsys.us
2014年9月10日 TUE / 21:56 / version 0.1 